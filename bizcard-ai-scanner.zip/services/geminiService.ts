import { GoogleGenAI, Type, Schema } from "@google/genai";
import { BusinessCardData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const cardSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    fullName: { type: Type.STRING, description: "Full name of the person" },
    jobTitle: { type: Type.STRING, description: "Job title or position" },
    company: { type: Type.STRING, description: "Company or organization name" },
    phone: { type: Type.STRING, description: "Primary phone number in international format if possible" },
    email: { type: Type.STRING, description: "Email address" },
    website: { type: Type.STRING, description: "Website URL" },
    address: { type: Type.STRING, description: "Physical address" },
    notes: { type: Type.STRING, description: "A brief summary or tagline found on the card" },
  },
  required: ["fullName", "company", "phone"],
};

export const analyzeBusinessCard = async (base64Image: string): Promise<BusinessCardData> => {
  try {
    // Remove header if present (data:image/jpeg;base64,)
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64,
            },
          },
          {
            text: "Extract contact information from this business card image. Format phone numbers for WhatsApp (remove spaces/dashes if possible, include country code if visible). If a field is missing, return an empty string.",
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: cardSchema,
        temperature: 0.1, // Low temperature for factual extraction
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("NO_TEXT_GENERATED");
    }

    try {
      return JSON.parse(text) as BusinessCardData;
    } catch (parseError) {
      console.error("JSON Parse Error:", parseError);
      throw new Error("JSON_PARSE_FAILED");
    }
  } catch (error: any) {
    console.error("Gemini extraction error:", error);
    
    // Categorize errors for the UI
    const msg = (error.message || "").toLowerCase();
    
    if (msg.includes("api key") || msg.includes("403")) {
      throw new Error("API_KEY_ERROR");
    }
    if (msg.includes("network") || msg.includes("fetch") || msg.includes("offline")) {
      throw new Error("NETWORK_ERROR");
    }
    if (msg.includes("503") || msg.includes("overloaded")) {
      throw new Error("SERVER_BUSY");
    }
    if (msg.includes("safety") || msg.includes("blocked")) {
      throw new Error("SAFETY_BLOCK");
    }
    if (error.message === "NO_TEXT_GENERATED") {
      throw new Error("EMPTY_RESPONSE");
    }
    if (error.message === "JSON_PARSE_FAILED") {
      throw new Error("PARSE_ERROR");
    }

    throw new Error("UNKNOWN_ERROR");
  }
};