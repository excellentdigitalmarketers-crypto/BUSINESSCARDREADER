import React from 'react';
import { ScanLine, Sparkles } from 'lucide-react';

const ProcessingView: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute inset-0 bg-blue-100 rounded-xl animate-pulse"></div>
        <div className="absolute inset-0 flex items-center justify-center text-blue-600">
          <ScanLine className="w-12 h-12 animate-bounce" />
        </div>
        <div className="absolute -top-2 -right-2">
          <Sparkles className="w-6 h-6 text-yellow-400 animate-spin-slow" />
        </div>
      </div>
      <h3 className="text-xl font-bold text-slate-800 mb-2">AI is Reading...</h3>
      <p className="text-slate-500 max-w-xs">
        Gemini is analyzing the text and extracting contact details. This typically takes a few seconds.
      </p>
    </div>
  );
};

export default ProcessingView;